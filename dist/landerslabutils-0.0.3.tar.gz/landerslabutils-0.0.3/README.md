# LandersLabUtils
A collection of Hail functions aims to extract data from ALS Compute.
LandersLabutils is released on PyPI.

Full detailed documentation is available at:

[landerslabutils](https://albertobrusati.github.io/LandersLabUtils/).
